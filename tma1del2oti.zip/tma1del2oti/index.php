<?php
/*
Plugin Name: Delete Files oti php7.4
Plugin URI: https://t-ma.ir/delete-files
Description: A plugin that deletes files with .oti and .ccss extensions
Version: 1.0
Author: محمد باقری
Author URI: https://t-ma.ir
License: GPL2
*/

// تابعی برای حذف فایل‌های با پسوند .oti و .ccss
function delete_files($dir) {
  // باز کردن پوشه
  $handle = opendir($dir);
  // خواندن فایل‌ها و پوشه‌های داخل پوشه
  while (($file = readdir($handle)) !== false) {
    // اگر فایل یا پوشه نادیده گرفته شود
    if ($file == "." || $file == "..") {
      continue;
    }
    // تشکیل مسیر کامل فایل یا پوشه
    $path = $dir . "/" . $file;
    //echo $path;
    // اگر پوشه باشد
    if (is_dir($path)) {
      // بازگشتی فراخوانی تابع برای پوشه
      delete_files($path);
    }
    // اگر فایل باشد
    else {
      // بدست آوردن پسوند فایل
      $ext = pathinfo($path, PATHINFO_EXTENSION);
      
      // اگر پسوند فایل .oti یا .ccss باشد
      if ($ext == "oti" || $ext == "ccss") {
        // حذف فایل
        unlink($path);
      }
    }
  }
  // بستن پوشه
  closedir($handle);
}

// اضافه کردن یک اکشن برای اجرای تابع در هر روز
add_action('daily_event', 'delete_files');

// بررسی کردن اینکه آیا اکشن زمان‌بندی شده است یا خیر
if (!wp_next_scheduled('daily_event')) {
  // اگر نه، زمان‌بندی کردن اکشن برای اجرا در هر روز
  wp_schedule_event(time(), 'daily', 'daily_event');
}

// فراخوانی تابع برای پوشه ریشه
delete_files(".");
